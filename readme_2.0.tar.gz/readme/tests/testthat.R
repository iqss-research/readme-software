# This file is part of the standard testthat test infrastructure
library(testthat)
library(readme)

test_check("readme")
