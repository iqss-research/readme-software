f2n <- function(.){as.numeric(as.character(.))}

vec2prob <- function(.){x <- table(.); x/sum(x)}

getEnvOf <- function(what, which=rev(sys.parents())) {
  for (frame in which)
    if (exists(what, frame=frame, inherits=FALSE)) 
      return(sys.frame(frame))
  return(NULL)
}

library2 <- function(lib_name, loadin = T){ 
  eval_value <- try(class(lib_name), T)
  if( eval_value != "character" | class(eval_value) == "try-error" ){ lib_name <- deparse(substitute(lib_name)) } 
  if( !lib_name %in% rownames(installed.packages()) ){
    LIB_counter <- 0; LIB_ok <- F 
    while(LIB_ok == F){ 
      LIB_counter <- LIB_counter + 1 
      print(sprintf("Trying %s for %s", .libPaths()[LIB_counter], lib_name))
      try(eval(parse(text = sprintf("install.packages('%s', 
                                    repos = 'http://cran.us.r-project.org',
                                    lib = .libPaths()[LIB_counter] )", lib_name))), T)
      LIB_ok <- lib_name %in% rownames(installed.packages())
      if(LIB_counter > length(.libPaths())){LIB_ok <- T}
    }
  }
  if(loadin == T){ 
    eval(parse(text = sprintf("require('%s', quietly = T)", lib_name)))
  } 
}

knn_adapt <- function(reweightSet, fixedSet, k){
  library2("optmatch", loadin = F)
  fixedSet <- as.data.frame(  cbind(1, fixedSet)) ; colnames(fixedSet)[1] <- "fixed_indicator"
  reweightSet <- as.data.frame(  cbind(0, reweightSet))  ; colnames(reweightSet)[1] <- "fixed_indicator"
  dist_mat <- eval(parse(text = sprintf('optmatch::match_on(%s, 
                                        data = rbind(reweightSet, fixedSet),
                                        method = "euclidean")', 
                                        sprintf("fixed_indicator~%s", paste(colnames(reweightSet)[-1], collapse = "+"))) ) )
  match_indices_list <-  apply(dist_mat, 1, function(x){ 
    which_use <- which(x <= sort(x)[k] )
    which_use <- sample(which_use, k); list(which_use) } )
  max_matched_dists <- apply(as.matrix(1:nrow(dist_mat)), 1, function(x){  max(dist_mat[x,unlist(match_indices_list[[x]])] )[1]  })
  addback_radius <- summary(max_matched_dists)[2] 
  match_indices_addback_list <- apply(as.matrix(1:nrow(dist_mat)),1,function(x){ 
    addback_indices <- c()
    if( max(dist_mat[x,match_indices_list[[x]][[1]] ]) <= addback_radius ){ 
      addback_indices <- which(dist_mat[x,] <= addback_radius)
    }
    return( list( addback_indices ) )  })
  match_indices_vec <- unlist(match_indices_list); return_indices <- c(match_indices_vec, unique( unlist(match_indices_addback_list) )[!unique( unlist(match_indices_addback_list) ) %in% match_indices_vec])
  return(return_indices ) 
}

get_resample_weights_fxn <- function(DataBalance,resampleTrim){ 
  DataBalance <- apply(DataBalance, 2, function(x)  Winsorize(x, probs = c(0.01, 0.99)))
  colnames(DataBalance) <- sprintf("V%s", 1:ncol(DataBalance)) 
  
  glmnet_text <- 'c(predict(glmnet::cv.glmnet(x = as.matrix(DataBalance[,-1]) , 
  y = as.factor(DataBalance[,1]), family = "binomial", alpha = 1),
  type = "response", newx = DataBalance[,-1], s = "lambda.1se"))'
  if(nrow(DataBalance) <= 1000){ LabeledProbs <-  replicate(5, eval(parse(text = glmnet_text)))} 
  if(nrow(DataBalance) > 1000){ LabeledProbs <-  replicate(2, eval(parse(text = glmnet_text))) } 
  LabeledProbs <- try(rowMeans(LabeledProbs), T)
  if(class(LabeledProbs) == "try-error"){LabeledProbs <- rep(0.5, times = nrow(DataBalance))}
  resamp_training <- 1 / LabeledProbs[DataBalance[,1]==1] - 1
  resamp_training[resamp_training>resampleTrim*summary(resamp_training)[5]] <- resampleTrim*summary(resamp_training)[5]
  return( resamp_training )  
}

colSds <- function (x, center = NULL, dim. = dim(x)){ 
  n <- dim.[1]; x <- x * x; x <- colMeans(x); x <- (x - center^2)
  sqrt (  x * (n/(n - 1)) )  }

FastScale <- function(x) {
  cm = .colMeans(x, m = nrow(x), n = ncol(x))# Get the column means
  csd = colSds(x, center = cm)# Get the column sd
  x = t( (t(x) - cm) / csd )#form result 
  return(x)
} 

readme_est_fxn <- function(X, Y){ try(limSolve::lsei(A = X, B=Y, E=matrix(nrow=1, ncol=ncol(X), data=rep(1, ncol(X))), 
                                                                          F=c(1), G=diag(rep(1, ncol(X))), H = rep(0, ncol(X)))$X, TRUE)} 

Winsorize <- function (x, minval = NULL, maxval = NULL, probs = c(0.05, 0.95), 
                       na.rm = FALSE){
  if (is.null(minval) || is.null(maxval)) {
    xq <- quantile(x = x, probs = probs, na.rm = na.rm)
    if (is.null(minval)) { minval <- xq[1] } 
    if (is.null(maxval)) { maxval <- xq[2] } 
  }
  x[x < minval] <- minval
  x[x > maxval] <- maxval
  return(x)
}


tf_est_fxn <- function(in_dfm_labeled,in_dfm_unlabeled,
                       in_category_vec_labeled,plot_results = T, 
                       sgd_iters = 1000, get_features_only = F, get_features_only_input = NULL){ 
  sess$run(init)
  scale_fxn <- function(old_seq, newmin, newmax){(newmax - newmin) * (old_seq - min(old_seq)) / (max(old_seq) - min(old_seq)) + newmin}
  sgd_learning_rate_seq <- c(sapply(seq(0.01, 0.005, length.out =sgd_iters/22), function(xs) 
    {ae <- seq(1, 0, length.out = 11)^1.2; scale_fxn(c(ae,rev(ae)), 0.003, xs)}))
  #sgd_learning_rate_seq <- scale_fxn(seq(1, 0, length.out = 11)^1.2, 0.008, 0.01)
  #sgd_learning_rate_seq <- c(sgd_learning_rate_seq[-1], rev(sgd_learning_rate_seq)[-1])
  #sgd_learning_rate_seq <- rep(sgd_learning_rate_seq, ceiling(sgd_iters/length(sgd_learning_rate_seq)))
  #sgd_learning_rate_seq <- sgd_learning_rate_seq * scale_fxn(seq(1, 0, length.out = sgd_iters), newmin = 0.55, newmax = 1)
  #sgd_learning_rate_seq <- rev(sgd_learning_rate_seq^(scale_fxn(seq(1, 0, length.out = sgd_iters)^1.2, newmin = 0.5, newmax = 1) ))
  
  n_PureBatchNorm <- floor(sgd_iters*0.20);
  base_seq <- c(rep(0, times = n_PureBatchNorm), seq(0, 1, length.out = sgd_iters-n_PureBatchNorm )^5)
  rmax_seq <-  scale_fxn(base_seq, newmin = 1,  newmax = 2)
  dmax_seq <-  scale_fxn(base_seq, newmin = 0,  newmax = 1)#was 1.2 
  
  my_e <- 0.01
  MultMat <- matrix( my_e / (NCat_tf - 1), ncol = NCat_tf, nrow = sum(cat_batch))
  MultMat[up_indices] <- 1 * (1- my_e); MultMat <- MultMat/colSums(MultMat)
  MultMat <- t(MultMat)

  indices_by_cat <- tapply(1:length(in_category_vec_labeled), in_category_vec_labeled, c)
  
  IL_sigma_in = rep(1, times = ncol(in_dfm_labeled))
  IL_mu_in = rep(0, times = ncol(in_dfm_labeled))
  LF_sigma_in = rep(0.45, times = NProj_tf)
  LF_mu_in = rep(0.40, times = NProj_tf)
  my_v <- rep(NA, times = sgd_iters)
  start_time <-  proc.time()
  
  BATCH_INDICES_MAT <- replicate(sgd_iters,  {unlist(c(sapply(1:length(cat_batch), function(ze){ 
                                     needs_resampling <- cat_batch[ze] >= 0.95*length(indices_by_cat[[ze]])
                                     sample(indices_by_cat[[ze]],cat_batch[ze], replace = needs_resampling   ) })
                                    ))} )
  for(awer in 1:sgd_iters){ 
    TRAIN_DICT = dict(IL = in_dfm_labeled[BATCH_INDICES_MAT[,awer],],
                      sdg_learning_rate = sgd_learning_rate_seq[awer], 
                      rmax = rmax_seq[awer], dmax = dmax_seq[awer], 
                      
                      IL_mu_last =  IL_mu_in, 
                      IL_sigma_last = IL_sigma_in, 
                      
                      LF_mu_last =  LF_mu_in, 
                      LF_sigma_last = LF_sigma_in, 
                      
                      MultMat_tf = MultMat, training_tf = T )
    update_ls = sess$run(list(myOptimizer_tf,
                              IL_mu_,IL_sigma_,LF_mu_,LF_sigma_) ,  feed_dict = TRAIN_DICT )
    IL_mu_in = update_ls[[2]]
    IL_sigma_in = update_ls[[3]]
    LF_mu_in = update_ls[[4]]
    LF_sigma_in = update_ls[[5]]
  } 
  
  #https://arxiv.org/pdf/1702.03275.pdf
  if(get_features_only == T){ 
    return( sess$run(LFinal_final,feed_dict = dict(IL = get_features_only_input, training_tf = F,
                                                   rmax = c(1e10),dmax = c(1e10), 
                                                   IL_mu_last =  IL_mu_in, 
                                                   IL_sigma_last = IL_sigma_in, 
                                                   
                                                   LF_mu_last =  LF_mu_in, 
                                                   LF_sigma_last = LF_sigma_in) ) )
  }
  
  if(get_features_only == F){ 
    out_dfm = sess$run(LFinal_final,feed_dict = dict(IL = rbind(in_dfm_labeled, in_dfm_unlabeled),
                                                     training_tf = F,rmax = c(1e10),dmax = c(1e10),
                                                     IL_mu_last =  IL_mu_in, 
                                                     IL_sigma_last = IL_sigma_in, 
                                                     
                                                     LF_mu_last =  LF_mu_in, 
                                                     LF_sigma_last = LF_sigma_in) )
    out_dfm_labeled <- out_dfm[1:nrow(in_dfm_labeled), ]
    out_dfm_unlabeled <- out_dfm[-c(1:nrow(in_dfm_labeled)),]
    
    if(plot_results == T){
      print(proc.time() - start_time)
      plot_indices <- sample(1:ncol(out_dfm_unlabeled), 2)
      plot(out_dfm_unlabeled[,plot_indices],
           col = as.factor(categoryVec_unlabeled), main = "TEST", cex = 1.5, 
           xlab = "", ylab = "", pch = as.numeric(as.factor(categoryVec_unlabeled)))
      #plot(out_dfm_labeled[,plot_indices],col = as.factor(in_category_vec_labeled),cex = 1.5, pch = as.numeric(as.factor(in_category_vec_labeled)))
    }
    
    if(nrow(out_dfm_labeled) <= 1000){ MatchIndices <- knn_adapt(reweightSet = out_dfm_labeled, fixedSet = out_dfm_unlabeled, k = 3)}
    if(nrow(out_dfm_labeled) > 1000){ library2("FNN", loadin = F); MatchIndices <- c(FNN::knnx.index(data = out_dfm_labeled, query = out_dfm_unlabeled, k = 3))} 
    
    min_n_by_cat <- 10
    reweighted_in_category_tabulation <- table(as.factor( in_category_vec_labeled )  [unique(MatchIndices)])
    cats_need_more_docs <- names(reweighted_in_category_tabulation)[reweighted_in_category_tabulation < min_n_by_cat]
    if(length(cats_need_more_docs) > 0){ 
      library2("optmatch", loadin = F)
      fixedSet <- as.data.frame(  cbind(1, out_dfm_unlabeled)) 
      reweightSet <- as.data.frame(  cbind(0, out_dfm_labeled))  
      colnames(fixedSet)[1] <- colnames(reweightSet)[1] <- "fixed_indicator"
      dist_match <- eval(parse(text = sprintf('optmatch::match_on(%s, 
                                              data = rbind(reweightSet, fixedSet),
                                              method = "euclidean")', 
                                              sprintf("fixed_indicator~%s", paste( colnames(reweightSet)[-1], collapse = "+"))) ) )
      for(cat_need_more_docs in cats_need_more_docs){ 
        need_cat_indices <- unique(  which(in_category_vec_labeled %in% cat_need_more_docs) )
        available_indices <- need_cat_indices[!need_cat_indices %in% unique(MatchIndices)]
        available_dists <- dist_match[,available_indices]
        
        add_indices <- c()
        if(class(available_dists) == "numeric"){ add_indices <- available_indices }
        if(class(available_dists) %in% c("matrix", "data.frame")){ 
          need_quota <- min_n_by_cat - reweighted_in_category_tabulation[cat_need_more_docs]
          need_quota <- min(need_quota, length(available_indices))
          available_dists_min <- apply(available_dists, 2, min)
          add_indices <- available_indices[which(available_dists_min %in% sort(available_dists_min)[1:need_quota ])]
        } 
        MatchIndices <- c(MatchIndices, add_indices)
      }
    }
    
    MatchIndices_ordered_by_cat <- unlist(  tapply(MatchIndices, as.factor( in_category_vec_labeled )[MatchIndices], 
                                                   function(at){  my_tab <- c(table(at)); MaxN <- Inf
                                                   return_indices <- try(as.numeric(as.character(unlist( sapply(1:length(my_tab), function(jab){
                                                     rep(names(my_tab[jab]), times = min(c(my_tab[jab], MaxN))) })))), T)
                                                   return( return_indices ) }) )
    reweighted_in_category_vec_labeled <- as.factor( in_category_vec_labeled )  [MatchIndices_ordered_by_cat]
    out_dfm_labeled_match <-  out_dfm_labeled[MatchIndices_ordered_by_cat,]
    cat_indices_match <- try(tapply(1:nrow(out_dfm_labeled_match),reweighted_in_category_vec_labeled,function(x){ c(x) } ) , T) 
    my_e2 <- 0.01
    MultMat2_temp <- matrix( 0, nrow = NCat_tf, ncol = nrow(out_dfm_labeled_match))
    MultMat2_temp <- t( sapply(1:NCat_tf, function(dab){ 
      ab <- MultMat2_temp; ab[dab,] <- my_e2 / (NCat_tf - 1); my_indices_dab <- cat_indices_match[[dab]]
      ab[dab,my_indices_dab] <-  1 * (1-my_e2); ab[dab,] <- ab[dab,]  / sum(ab[dab,])
      return( ab[dab,] )  
    } )  )
    ESGivenD = t(MultMat2_temp %*% out_dfm_labeled_match); colnames(ESGivenD) <- names(cat_indices_match)
    ES <- colMeans(out_dfm_unlabeled)
    est_readme2 <- try(readme_est_fxn(X = ESGivenD, Y = ES)[cat_names],T)
    if(class(est_readme2) == "try-error"){est_readme2 <- labeled_pd; est_readme2[T == T] <- NA}
    ret_list <- list(est_readme2 = est_readme2, ESGivenD  = ESGivenD, ES = ES, 
                     DataBalance = rbind(cbind(1,out_dfm_labeled), cbind(0,out_dfm_unlabeled)), 
                     match_comparison = list(prematched = cbind(as.character(in_category_vec_labeled), out_dfm_labeled),
                                             matched = cbind(as.character(reweighted_in_category_vec_labeled), out_dfm_labeled_match), 
                                             test_set  = out_dfm_unlabeled ))
    
    return( ret_list ) 
  }
  }
