undergrad0 <- function(control, inputType="filenames", sep="\t", contentKey="ROWID", categoryKey = "CATEGORY", labeledSet_key = "LABELEDSET",
                      outputType="bin", ignoreCase=T, stripTags=T, stem=T, removePunctuation=T,
                      stopWords=T, removeNumbers=T, minFreq=0.05, maxFreq=0.95, language="en", verbose=T)
{
  library2("tm",loadin = F)
  ### Check 'inputType' file
  if (inputType != "filenames" & inputType != "raw"){
    stop("Error - 'inputType' must be either 'filenames' or 'raw'")
  }
  ### Check 'outputType'
  if (outputType != "bin" & outputType != "tf" & outputType != "tfIdf"){
    stop("Error - 'outputType' must be either 'bin', 'tf', or 'tfIdf'")
  }
  
  if (!is.character(sep)){
    stop("Error - 'sep' must be a character")
  }
  if(verbose == T){
    cat("Loading control file...\n")
  }
  ## If 'control' is a filename
  if (is.character(control)){
    ### Load in control file
    data_input <- utils::read.table(control, header=T, sep=sep, stringsAsFactors=F)
  }else{
    ### save "control" argument as data_input
    data_input <- control
  }
  
  ### Check to make sure contentKey, categoryKey and labeledSet_key
  if (!(contentKey %in% colnames(data_input))){
    stop("Error: 'contentKey' not in the column names of the input file") 
  }
  if (!(categoryKey %in% colnames(data_input))){
    stop("Error: 'categoryKey' not in the column names of the input file") 
  }
  if (!(labeledSet_key %in% colnames(data_input))){
    stop("Error: 'labeledSet_key' not in the column names of the input file") 
  }
  if(verbose == T){
    cat("Create source from control file...\n")
  }
  
  ### Make a source
  if (inputType == "filenames"){
    doc.source <- tm::URISource(data_input[[contentKey]])
  }
  if (inputType == "raw"){
    doc.source <- tm::VectorSource(data_input[[contentKey]])
  }
  if(verbose == T){
    cat("Generating Corpus...\n")
  }
  ### Turn into a corpus
  doc.corp <- tm::Corpus(doc.source)
  
  ########## Corpus manipulation ##############
  if(verbose == T){
    cat("Processing text...\n")
  }
  if(verbose == T){
    cat("\t Removing extra whitespace...\n")
  }
  #### Remove extra whitespace
  doc.corp <- tm::tm_map(doc.corp, tm::stripWhitespace)
  
  #### Strip tags
  if (stripTags){
    if(verbose == T){
      cat("\t Removing HTML/XML tags...\n")
    }
    doc.corp <- tm::tm_map(doc.corp, tm::content_transformer(function(x) {return(gsub("<.*?>", "", x))}))
  }
  
  #### To Lowercase
  if (ignoreCase){
    if(verbose == T){
      cat("\t Converting to lower case...\n")
    }
    doc.corp <- tm::tm_map(doc.corp, tm::content_transformer(base::tolower))
  }
  
  #### Remove Numbers
  if (removeNumbers){
    if(verbose == T){
      cat("\t Removing numbers...\n")
    }
    doc.corp <- tm::tm_map(doc.corp, tm::removeNumbers)
  }
  
  #### Remove Stop Words
  if (stopWords){
    if(verbose == T){
      cat("\t Removing Stop Words...\n")
    }
    doc.corp <- tm::tm_map(doc.corp, tm::content_transformer(function(x){tm::removeWords(x, tm::stopwords(language))}))
  }
  
  #### Remove punctuation
  if (removePunctuation){
    if(verbose == T){
      cat("\t Removing punctuation...\n")
    }
    doc.corp <- tm::tm_map(doc.corp, tm::removePunctuation)
  }
  
  #### Stemming
  if (stem){
    if(verbose == T){
      cat("\t Stemming documents...\n")
    }
    doc.corp <- tm::tm_map(doc.corp, tm::stemDocument)
  }
  
  if (verbose == T){
    cat("Finished processing text...\n")
  }
  
  if(verbose == T){
    cat("Creating Document-Term Matrix...\n")
  }
  
  ### Number of docs
  ndocs <- length(doc.corp)
  
  ### Create dtm
  if(length(doc.corp) > 20){ 
    dtm <- tm::DocumentTermMatrix(doc.corp, control= list(bounds = list(global = c(ndocs*minFreq, ndocs*maxFreq)), wordLengths=c(2, 100)))
  } 
  
  ### Do weighting 
  if (outputType == "bin"){
    dtm <- tm::weightBin(dtm)
  }else if (outputType == "tf"){
    dtm <- tm::weightTf(dtm)
  }else if (outputType == "tfIdf"){
    dtm <- tm::weightTfIdf(dtm)
  }
  
  dtm <- cbind(1:nrow(data_input), data_input[[categoryKey]], 
               data_input[[labeledSet_key]], as.data.frame(as.matrix(dtm)))
  colnames(dtm)[c(1,2,3)] <- c("DOCKEY", "CATEGORY", "LABELEDSET")
  
  if (verbose == T){
    cat("Finished!\n")
  }
  
  return(dtm)
}