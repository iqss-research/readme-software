#' A algorithm for quantification that harnesses the Law of Total Expectations in an optimal feature space 
#'
#'
#'
#' An R package for estimating category proportions in an unlabeled set of documents by implementing the method described in Jerzak, King, and Strezhnev (2018). 
#' This method is meant to improve on the ideas in Hopkins and King (2010), which introduced a quantification algorithm that harnesses the Law of Total Expectation. 
#' We apply this law in a feature space that is now crafted to minimize the error of the resulting estimate. Automatic differentiation, stochastic gradient descent, and batch re-normalization are used to carry out the optimization. Other pre-processing functions are available, 
#' as well as an interface to the earlier version of the algorithm. The package also provides users with the ability to extract the generated features for other tasks.
#' 
#' 
#' The package provides two main functions: \code{undergrad} and \code{readme}. 
#' 
#'\itemize{
#'   \item \code{undergrad} takes as an input a word vector corpus (or pointer to such a corpus) and 
#'   a vector housing cleaned text for cross-referencing with the vector corpus. It returns document-level 
#'   summaries of each of the dimensions of the word vectors (\code{min}, \code{median}, and \code{max} of each dimension within each document are calculated). 
#'   Options also exist for generating a document-term matrix from the text. 
#'   \item \code{readme} takes as an input a document feature matrix (preferably, the output from \code{undergrad}). 
#'   It also takes as an input an indicator vector denoting which documents are labeled and 
#'   a vector indicating category membership (\code{NA}s for unlabeled documents). 
#'   The algorithm then generates an optimal projection for harnessing the Law of Total Expectation in calculating the 
#'   estimated category proportions in the unlabeled set.
#' }
#' 
#' @section Usage: 
#' For guidance on usage, see \strong{Examples}.  
#' 
#' @section Authors: 
#' \itemize{
#'   \item Connor Jerzak, Anton Strezhnev, and Gary King. 
#'   \item Maintainer: Connor Jerzak <cjerzak@gmail.com> 
#' }
#' 
#' @section References: 
#' \itemize{ 
#' \item Hopkins, Daniel, and King, Gary (2010), 
#' \emph{A Method of Automated Nonparametric Content Analysis for Social Science},
#' \emph{American Journal of Political Science}, Vol. 54, No. 1, January 2010, p. 229-247. 
#' \url{https://gking.harvard.edu/files/words.pdf} 
#' 
#' \item Jerzak, Connor, King, Gary, and Strezhnev, Anton. Working Paper. 
#' \emph{An Improved Method of Automated Nonparametric Content Analysis for Social Science}. 
#' \url{https://gking.harvard.edu/words} 
#' }
#' 
#' @examples 
#' #set the seed 
#' set.seed(1)
#' 
#' #Generate synthetic word vector corpus using a random vocabulary of size 100. 
#' my_vocab <- replicate(100, paste(sample(letters, 4, replace = T), collapse = "") ) 
#' synthetic_vector_corpus <- data.frame(matrix(rnorm(100*50), ncol = 50))
#' synthetic_corpus <- cbind(my_vocab, synthetic_vector_corpus)
#' synthetic_corpus <- data.table::as.data.table(synthetic_corpus)
#' 
#' #Setup 50 ``documents'' of 10 words apiece. 
#' my_documents <- replicate(50, paste(sample(my_vocab, 10), collapse = " ") )
#' 
#' #Get document-level word vector summaries. 
#' my_dfm <- undergrad(documentText = my_documents, wordVecs_corpus = synthetic_corpus)
#' 
#' #randomly assign labeled/unlabeled assignment for the 50 documents 
#' my_labeledIndicator <- sample(c(0,1), size = 50, replace = T)
#' 
#' #randomly assign category membership for the 50 documents. There are 3 categories in this example. 
#' my_categoryVec <- sample(c("C1", "C2", "C3"), 50, replace = T)
#' true_unlabeled_pd <- prop.table(table(my_categoryVec[my_labeledIndicator==0]))
#' my_categoryVec[my_labeledIndicator == 0] <- NA
#' 
#' #perform estimation
#' readme_results <- readme(dfm = my_dfm, 
#'                          labeledIndicator=my_labeledIndicator, 
#'                          nboot = 3, categoryVec = my_categoryVec)
#'print(readme_results$point_readme)
#'print(true_unlabeled_pd)
#'
#' @docType package
#' @name readme-package
NULL