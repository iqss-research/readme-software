
#' readme
#' 
#' Implements the quantification algorithm described in Jerzak, King, and Strezhnev (2018) which is meant to improve on the ideas in Hopkins and King (2010).
#' Employs the Law of Total Expectation in a feature space that is crafted to minimize the error of the resulting estimate. Automatic differentiation, stochastic gradient descent, and batch re-normalization are used to carry out the optimization.
#' Takes an inputs (a.) a document-feature matrix, (b.) a vector indicating category membership 
#' (with \code{NA}s for the unlabeled documents), and (c.) a vector indicating whether the labeled or unlabeled status of each document. 
#' 
#' @param dfm 'document-feature matrix'. A data frame where each row represents a document and each column a unique feature. 
#' 
#' @param labeledIndicator An indicator vector where each entry corresponds to a row in \code{dfm}. 
#' \code{1} represents document membership in the labeled class. \code{0} represents document membership in the unlabeled class. 
#' 
#' @param categoryVec An factor vector where each entry corresponds to the document category. 
#' The entires of this vector should correspond with the rows of \code{dtm}. 
#'
#' @param nboot A scalar indicating the number of times the estimation will be re-run, either with or without 
#' re-sampling of documents (see \code{resample}).
#' 
#' @param resample A Boolean indicating whether documents should be resampled using propensity weights in the estimation. 
#' 
#' @param resampleTrim A scalar (usually between 1 and 10) which controls 
#' truncation of the resampling weights. A value of \code{k} means that all weights greater than 
#' \code{k} times the 3rd quartile will be truncated. 
#' 
#' @param verbose A Boolean indicating whether exploratory plots should be shown. 
#' 
#' @param diagnostics A Boolean indicating whether diagnostics should be saved in the output list. 
#' 
#' @param justTransform A Boolean indicating whether the user wants to extract the quanficiation-optimized 
#' features only.  
#' 
#' @param readmeVersion A character string taking on values either \code{"1"} or \code{"2"} indicating 
#' the version of the \code{readme} algorithm to employ. \code{"2"} is highly recommended. If using \code{"1"}, 
#' the \code{dfm} should be a document-term matrix. If using \code{"2"}, document-level word vector summaries should be supplied. 
#' 
#' @return A list consiting of \itemize{
#'   \item estimated category proportions in the unlabeled set (\code{point_readme});
#'   \item (if \code{readmeVersion = "2"}) transformed dfm optimized for quantification (\code{transformed_dfm}); 
#'   \item (optionally and if \code{readmeVersion} = "2") a list containing various diagnostics from the estimation. 
#' }
#'
#' @section References:
#' \itemize{ 
#' \item Hopkins, Daniel, and King, Gary (2010), 
#' \emph{A Method of Automated Nonparametric Content Analysis for Social Science},
#' \emph{American Journal of Political Science}, Vol. 54, No. 1, January 2010, p. 229-247. 
#' \url{https://gking.harvard.edu/files/words.pdf} 
#' 
#' \item Jerzak, Connor, King, Gary, and Strezhnev, Anton. Working Paper. 
#' \emph{An Improved Method of Automated Nonparametric Content Analysis for Social Science}. 
#' \url{https://gking.harvard.edu/words} 
#' }
#' 
#' @examples 
#' #set seed 
#' set.seed(1)
#' 
#' #setup synthetic dfm 
#' my_dfm <- matrix(rnorm(100*20), ncol = 20)
#' 
#' #randomly assign labeled/unlabeled assignment 
#' my_labeledIndicator <- sample(c(0,1), size = 100, replace = T)
#' 
#' #randomly assign category membership 
#' my_categoryVec <- sample(c("C1", "C2", "C3"), 100, replace = T)
#' true_unlabeled_pd <- prop.table(table(my_categoryVec[my_labeledIndicator==0]))
#' my_categoryVec[my_labeledIndicator == 0] <- NA
#' 
#' #perform estimation
#' readme_resutls <- readme(dfm = my_dfm, 
#'        labeledIndicator=my_labeledIndicator, 
#'        nboot = 3, categoryVec = my_categoryVec)
#'print(readme_resutls$point_readme)
#'print(true_unlabeled_pd)
#' @export 
#' 

readme <-  function(dfm, labeledIndicator, categoryVec, nboot = 10,  
                     resample = T, resampleTrim =3, verbose=F, diagnostics = F, justTransform = F,
                     readmeVersion = "2"){ 
  if(readmeVersion == "1"){ 
    return(  readme0(dtm = dfm, 
           labeledIndicator = labeledIndicator, 
           categoryVec=categoryVec,
           features = 15, 
           nboot = nboot, 
           probWt = 1) )  
  }
  if(readmeVersion == "2"){ 
  library2("tensorflow", loadin = T)
  library2("glmnet",loadin = F)
  library2("limSolve", loadin = F)
  
  #setup things for iterations 
  categoryVec_unlabeled <- categoryVec[labeledIndicator == 0]
  categoryVec_labeled <- categoryVec[labeledIndicator == 1]
  labeled_pd <- vec2prob(categoryVec_labeled)
  unlabeled_pd <- vec2prob( categoryVec_unlabeled )
  cat_names <- names(labeled_pd)
  nCat <- length(labeled_pd)
  dfm_labeled <- dfm[labeledIndicator==1,]
  dfm_unlabeled <- dfm[labeledIndicator==0,]
  
  #drop constant columns 
  dfm_MEANs <- colMeans( dfm_labeled )
  dfm_SDs <- colSds(dfm_labeled, center =  dfm_MEANs) 
  dfm_labeled <- t( (t(dfm_labeled) - dfm_MEANs) / (dfm_SDs+0.01) ) ; dfm_unlabeled = t( (t(dfm_unlabeled) - dfm_MEANs) / (dfm_SDs+0.01) )
  dfm_labeled <- dfm_labeled[,!(dfm_SDs == 0)]; 
  if(nrow(dfm_unlabeled) > 1){ dfm_unlabeled <- dfm_unlabeled[,!(dfm_SDs==0)] } 
  
  #tf setup 
  NPassin_tf <- ncol(dfm_labeled)
  tf_batch_size_byCat <- as.integer(10)
  NCat_tf <- as.integer( nCat )
  NProj_tf <- as.integer( min(max(10,NCat_tf+2), 15) )
  environment(tf_est_fxn) <- getEnvOf( "NPassin_tf" )
  { 
    tf$reset_default_graph()
    sess <- tf$Session()
    
    cat_batch <- rep(tf_batch_size_byCat, times = NCat_tf); 
    up_indices <- c(sapply( 1:NCat_tf, function(ser){ 1:tf_batch_size_byCat + (NCat_tf+1) * (ser-1)*tf_batch_size_byCat} ) )
    
    contrasts_mat <-  combn(1:NCat_tf, 2) - 1
    contrast_indices1 <- as.integer(contrasts_mat[1,]); contrast_indices2 <- as.integer(contrasts_mat[2,])
    
    redund_mat <- combn(1:NProj_tf, 2) - 1
    redund_indices1 <- as.integer(redund_mat[1,]); redund_indices2 <- as.integer(redund_mat[2,])
    axis_FeatDiscrim = as.integer(NCat_tf!=2)
    
    training_tf <-  tf$placeholder(tf$bool, shape = shape())
    sdg_learning_rate = tf$placeholder(tf$float32, shape = c())
    rmax = tf$placeholder(tf$float32, shape = c(), name = 'rmax')
    dmax = tf$placeholder(tf$float32, shape = c(), name = 'dmax')
    MultMat_tf = tf$placeholder(tf$float32, shape = shape( NCat_tf, NULL)) 
    
    my_decay <- 0.90
    IL <-  tf$placeholder(tf$float32, shape = list(NULL, NPassin_tf))
    {
      IL_m = tf$nn$moments(IL, axes = 0L);
      IL_mu_b = IL_m[[1]]
      IL_sigma2_b = IL_m[[2]]
      IL_sigma_b = tf$sqrt(IL_sigma2_b)
      IL_mu_last = tf$placeholder( tf$float32,shape(dim(IL_mu_b)) )
      IL_sigma_last = tf$placeholder( tf$float32,shape(dim(IL_sigma_b)) )
      IL_mu_ = (1-my_decay)  * IL_mu_b + my_decay * IL_mu_last
      IL_sigma_ = (1-my_decay) * IL_sigma_b + my_decay * IL_sigma_last
      IL_r = tf$stop_gradient(tf$clip_by_value(IL_sigma_b / IL_sigma_ , 1/rmax, rmax))
      IL_d = tf$stop_gradient(tf$clip_by_value( (IL_mu_b - IL_mu_) / IL_sigma_, -dmax, dmax))
      IL_n0 = tf$nn$batch_normalization(IL, mean = IL_mu_b, variance = IL_sigma2_b, offset = 0, scale = 1, variance_epsilon = 0.001)
      IL_n = IL_n0 * IL_r + IL_d
    } 
    IL_dn0 = tf$layers$dropout(IL_n, rate = 0.5, training = training_tf,noise_shape = list( 1L,tf$shape(IL)[[1]]))
    IL_dn = tf$reshape(IL_dn0, tf$shape(IL))
    
    LFinal =   tf$minimum(tf$layers$dense(inputs = IL_dn, units = NProj_tf,activation  =  tf$nn$relu, use_bias = T ), 1)
    { 
      LFinal_m = tf$nn$moments(LFinal, axes = 0L);
      LF_mu_b = LFinal_m[[1]]
      LF_sigma2_b = LFinal_m[[2]]
      LF_sigma_b = tf$sqrt(LF_sigma2_b)
      LF_mu_last = tf$placeholder( tf$float32,shape(dim(LF_mu_b)) )
      LF_sigma_last = tf$placeholder( tf$float32,shape(dim(LF_sigma_b)) )
      LF_sigma_ = (1-my_decay) * LF_sigma_b + my_decay * LF_sigma_last
      LF_mu_ = (1-my_decay) * LF_mu_b + my_decay * LF_mu_last
      LF_r = tf$stop_gradient(tf$clip_by_value(LF_sigma_b / LF_sigma_ , 1/rmax, rmax))
      LF_d = tf$stop_gradient(tf$clip_by_value( (LF_mu_b - LF_mu_) / LF_sigma_, -dmax, dmax))
      LFinal_n0 = tf$nn$batch_normalization(LFinal, mean = LF_mu_b, variance = LF_sigma2_b, offset = 0, scale = 1, variance_epsilon = 0.001)
      LFinal_n = LFinal_n0 * LF_r + LF_d
    } 
    MyPrSGivenD = tf$matmul(MultMat_tf, LFinal_n)
    
    CatDiscrim =  ( tf$abs( tf$gather(MyPrSGivenD, contrast_indices1, axis = 0L) - tf$gather(MyPrSGivenD, contrast_indices2, axis = 0L)) ) 
    FeatDiscrim =  tf$abs( tf$gather(CatDiscrim,  indices = redund_indices1, axis = axis_FeatDiscrim) - tf$gather(CatDiscrim, redund_indices2, axis = axis_FeatDiscrim)  )
    
    IL_final = tf$nn$batch_normalization(IL, mean = IL_mu_last, variance = tf$square(IL_sigma_last), offset = 0, scale = 1, variance_epsilon = 0.001)
    LFinal_final0 = tf$minimum( tf$nn$relu(  tf$matmul(IL_final, tf$trainable_variables()[[1]]) + tf$trainable_variables()[[2]] ), 1)
    LFinal_final = tf$nn$batch_normalization(LFinal_final0, mean = LF_mu_last, variance = tf$square(LF_sigma_last), offset = 0, scale = 1, variance_epsilon = 0.001)
    
    myLoss_tf =  -( (tf$reduce_mean(CatDiscrim)) + (tf$reduce_mean(FeatDiscrim)))
    myOptimizer_tf = tf$train$AdamOptimizer(learning_rate = sdg_learning_rate)$minimize(myLoss_tf,  var_list =  tf$trainable_variables())
    
    init = tf$global_variables_initializer()
  }
  
  if(justTransform == T){
    dfm_normalized = t( (t(dfm) - dfm_MEANs) / (dfm_SDs+0.01) )
    dfm_normalized <- dfm_normalized[,!(dfm_SDs == 0)]
    tf_est_results <- try(tf_est_fxn(in_dfm_labeled = dfm_labeled, 
                                     in_dfm_unlabeled = dfm_unlabeled, 
                                     in_category_vec_labeled = categoryVec_labeled, 
                                     sgd_iters = 1000, plot_results = verbose,
                                     get_features_only = T, 
                                     get_features_only_input = dfm_normalized), T)
    return(list(transformed_dfm=tf_est_results))
  } 
  
  if(justTransform == F){
  if(resample == T){ 
    nboot <- nboot + 1; 
    cat_indices_use_resample <- tapply(1:nrow(dfm_labeled), categoryVec_labeled, function(x) x) 
  }
  boot_readme <- matrix(nrow=nboot, ncol=nCat)
  colnames(boot_readme) <- cat_names
  hold_coef <- rep(0, nCat); names(hold_coef) <- cat_names
  MatchedPrD_div <- OrigPrD_div <- OrigESGivenD_div <- MatchedESGivenD_div <- rep(NA, times = nboot)
  for(iter_i in 1:nboot){ 
    if(iter_i == 1 | resample == F){ labeled_boot_indices <- 1:nrow(dfm_labeled) } 
    if(iter_i > 1 & resample == T){ 
      labeled_boot_indices <- sample(1:nrow(dfm_labeled), nrow(dfm_labeled), replace=T, prob=resamp_labeled) 
    
      cats_to_resample_labeled <- table( categoryVec_labeled[labeled_boot_indices]  )
      cats_to_resample_labeled <- names(cats_to_resample_labeled)[cats_to_resample_labeled < 10]
      unsampled_cats <- cat_names[cat_names %in% cats_to_resample_labeled]
      if(length(unsampled_cats) > 0){
        labeled_boot_indices <- c(labeled_boot_indices, unlist(  lapply(cat_indices_use_resample[as.character(unsampled_cats)],
                                                                        function(x){
                                                                          if(length(x) > 1){x <- sample(x, min(length(x),10))}
                                                                          return(x) } ) )  )
      }
    } 
    
    categoryVec_labeled_boot <- categoryVec_labeled[labeled_boot_indices]
    categoryVec_unlabeled_boot <- categoryVec_unlabeled
    
    dfm_labeled_boot <- dfm_labeled[labeled_boot_indices,]
    dfm_labeled_boot <- apply(dfm_labeled_boot, 2, function(x){x <- x + rnorm(length(x), 0, 0.0001)})
    dfm_unlabeled_boot <- dfm_unlabeled
    
    if(resample == T){ 
      cm = colMeans(dfm_labeled_boot); csd = colSds(dfm_labeled_boot, center = cm)
      dfm_labeled_boot <- t( (t(dfm_labeled_boot) - cm) / (csd+0.001) ) ; dfm_unlabeled_boot = t( (t(dfm_unlabeled_boot) - cm) / (csd+0.001) )
    }

    tf_est_results <- try(tf_est_fxn(in_dfm_labeled = dfm_labeled_boot, 
                                     in_dfm_unlabeled = dfm_unlabeled_boot, 
                                     in_category_vec_labeled = categoryVec_labeled_boot, 
                                     sgd_iters = 1000, plot_results = verbose), T)
    if(iter_i == 1){ 
      transformed_dfm = tf_est_results$DataBalance[,-1]
      transformed_dfm[] <- NA
      transformed_dfm[which(labeledIndicator==1),] <- tf_est_results$DataBalance[tf_est_results$DataBalance[,1]==1,-1] 
      transformed_dfm[which(labeledIndicator==0),] <- tf_est_results$DataBalance[tf_est_results$DataBalance[,1]==0,-1] 
    }
    if(iter_i == 1 & resample == T){ resamp_labeled <- get_resample_weights_fxn(DataBalance=tf_est_results$DataBalance,resampleTrim=resampleTrim) } 
    est_readme <- tf_est_results$est_readme
    if(class(est_readme) == "try-error"){ print("ERROR HERE 1");if(verbose){browser()}; est_readme <- labeled_pd; est_readme[1:length(est_readme)] <- NA }
    temp_est_readme <- hold_coef 
    temp_est_readme[names(est_readme)] <- est_readme
    boot_readme[iter_i,names(temp_est_readme)] <- temp_est_readme
    
    if(diagnostics == T){ 
      PrDDiv_matched <- sum(abs((vec2prob(tf_est_results$match_comparison$matched[,1]))[names(unlabeled_pd)] - unlabeled_pd))
      OrigPrD <- vec2prob(categoryVec_labeled_boot)
      
      ESGivenD_div <- try({ 
        OldMat <- apply(tf_est_results$match_comparison$prematched[,-1], 2, f2n)
        PreMachedMat <-  tapply(1:length(tf_est_results$match_comparison$prematched[,1]), tf_est_results$match_comparison$prematched[,1], function(za){
          colMeans(OldMat[za,])
        })
        PreMachedMat <- do.call(cbind, PreMachedMat)
        
        NewMat <- apply(tf_est_results$match_comparison$matched[,-1], 2, f2n)
        PostMachedMat <-  tapply(1:length(tf_est_results$match_comparison$matched[,1]), tf_est_results$match_comparison$matched[,1], function(za){
          colMeans(NewMat[za,])
        })
        PostMachedMat <- do.call(cbind, PostMachedMat)
        
        TestSet <- apply(tf_est_results$match_comparison$test_set, 2, f2n)
        TruthMat <-  tapply(1:nrow(TestSet), categoryVec_unlabeled_boot, function(za){
          colMeans(TestSet[za,]) })
        TruthMat <- do.call(cbind, TruthMat)
        
        oldESGivenD_div = mean(abs(c(PreMachedMat[,colnames(TruthMat)]) - c(TruthMat)))
        newESGivenD_div = mean(abs(c(PostMachedMat[,colnames(TruthMat)]) - c(TruthMat)))
        t( data.frame(oldESGivenD_div = oldESGivenD_div, newESGivenD_div = newESGivenD_div, 
                      discrimination_metric = mean(apply(PostMachedMat, 1, sd)) ) ) 
      }, T)
      
      OrigPrD_div[iter_i] <- sum(abs(OrigPrD[names(unlabeled_pd)] - unlabeled_pd))
      MatchedPrD_div[iter_i] <- PrDDiv_matched
      
      OrigESGivenD_div[iter_i] <- try(ESGivenD_div["oldESGivenD_div",1], T) 
      MatchedESGivenD_div[iter_i] <- try(ESGivenD_div["newESGivenD_div",1], T)  
    } 
  }
  sess$close()
  
  if(resample == T){
    boot_readme <- boot_readme[-1,];
    OrigPrD_div <- OrigPrD_div[-1]; MatchedPrD_div <- MatchedPrD_div[-1]
    OrigESGivenD_div <- OrigESGivenD_div[-1]; MatchedESGivenD_div <- MatchedESGivenD_div[-1]
  }
  point_readme <- colMeans(boot_readme, na.rm = T) 
  
  if(diagnostics == F){return( list(point_readme=point_readme, 
                                    transformed_dfm = transformed_dfm) )  }
  if(diagnostics == T){return( list(point_readme = point_readme,
                                    transformed_dfm = transformed_dfm, 
                                    diagnostics = list(OrigPrD_div = mean(OrigPrD_div, na.rm = T), 
                                    MatchedPrD_div = mean(MatchedPrD_div, na.rm = T), 
                                    OrigESGivenD_div = mean(OrigESGivenD_div, na.rm = T), 
                                    MatchedESGivenD_div = mean(MatchedESGivenD_div, na.rm = T))) )  }
  }
  }
}

