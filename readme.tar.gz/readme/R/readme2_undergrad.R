#' undergrad
#' 
#' Preprocessing for \code{readme} function - creates a document-feature matrix 
#' (saved as a data frame in output) to be passed to \code{readme}. Users can either input word-specific vectors 
#' using the \code{wordVecs_corpus} or \code{wordVecs_corpusPointer} parameters. 
#'
#' @param documentText A vector in which each entry corresponds to a ``clean'' document. 
#' Note that the function will take as a ``word'' all space-separated elements in each vector entry. For example,
#' \code{"star."} would have to have an exact analogue in the vector corpus, otherwise
#' it will be dropped in the calculations. It will be more common to space separate punctuation marks (i.e. 
#' \code{"star."} would become \code{"star ."}), since punctuation marks often have their own entries in the vector database. 
#' @param wordVecs_corpus A data.table object in which the first column holds the text of each word, 
#' and in which the remaining columns contain the numerical representation. Either \code{wordVecs_corpus} or 
#' \code{wordVecs_corpusPointer} should be null. 
#' @param wordVecs_corpusPointer A character string denoting where to find the \code{wordVecs_corpus} for loading into memory as a 
#' data.table. 
#' 
#' @param undergradVersion A character string taking on values either \code{"1"} or \code{"2"} indicating 
#' the version of the \code{undergrad} algorithm to employ. Use \code{"2"} for extracting document-level summaries of word vectors. 
#' Use \code{"1"} for extracting the unigrams (to create a document-term matrix). 
#' 
#' @param undergradVersion1_control A list containing additional parameters passed to version \code{"1"}.
#' 
#' @return A data.frame consisting of the \code{min}, \code{median}, and \code{maximum} of the word vectors by document.
#'  Each row corresonds to a document, and the columns to a particular summary of a particular word vector dimension. 
#' 
#' @examples 
#' #set seed 
#' set.seed(1) 
#' 
#' #Generate synthetic word vector corpus. 
#' synthetic_vector_corpus <- data.frame(matrix(rnorm(11*50), ncol = 50))
#' synthetic_corpus <- cbind(c("the","true", "thine", "stars", "are" , "fire", ".", "to", "own", "self", "be"), 
#'                           synthetic_vector_corpus)
#' synthetic_corpus <- data.table::as.data.table(synthetic_corpus)
#' 
#' #Setup ``documents'' 
#' my_documents <- c(
#' "the stars are fire .", #document 1 
#' "to thine own self be true .", #document 2 
#' "true stars be true ." #document 3
#' )
#' 
#' #Get document-level word vector summaries. 
#' my_dfm <- undergrad(documentText = my_documents, wordVecs_corpus = synthetic_corpus)
#' print( my_dfm ) 
#' 
#' @export 
#' 
#' 

undergrad <- function(documentText, wordVecs_corpus = NULL, wordVecs_corpusPointer = NULL,undergradVersion = "2",
                      undergradVersion1_control = list()){ 
  if(undergradVersion == "1"){ 
    control <- try(undergradVersion1_control$control,T) 
    inputType <- try(undergradVersion1_control$inputType,T) 
    sep <- try(undergradVersion1_control$sep, T); if(is.null(sep)){sep <- ""}
    contentKey <- try(undergradVersion1_control$contentKey,T) 
    categoryKey <- try(undergradVersion1_control$categoryKey,T) 
    labeledSet_key <- try(undergradVersion1_control$labeledSet_key,T) 
    
    stripTags <- try(undergradVersion1_control$stripTags,T) 
    if(is.null(stripTags)){stripTags <- T}
    stem <- try(undergradVersion1_control$stem,T) 
    if(is.null(stem)){stem <- T}
    removePunctuation <- try(undergradVersion1_control$removePunctuation,T) 
    if(is.null(removePunctuation)){removePunctuation <- T}
    stopWords <- try(undergradVersion1_control$stopWords,T) 
    if(is.null(stopWords)){stopWords <- T}
    removeNumbers <- try(undergradVersion1_control$removeNumbers,T) 
    if(is.null(removeNumbers)){removeNumbers <- T}
    ignoreCase <- try(undergradVersion1_control$ignoreCase,T) 
    if(is.null(ignoreCase)){ignoreCase <- T}
    stripTags <- try(undergradVersion1_control$stripTags,T) 
    if(is.null(stripTags)){stripTags <- T}
    minFreq <- try(undergradVersion1_control$minFreq,T) 
    if(is.null(minFreq)){minFreq <- 0.01}
    maxFreq <- try(undergradVersion1_control$maxFreq,T) 
    if(is.null(maxFreq)){maxFreq <- 0.99}
    language <- try(undergradVersion1_control$language,T) 
    if(is.null(language)){language <- "eng"}
    outputType <- try(undergradVersion1_control$outputType,T) 
    if(is.null(outputType)){outputType <- "bin"}
    
    return(  undergrad0(control=control, inputType=inputType, sep=sep, contentKey=contentKey,
                        categoryKey = categoryKey, 
                        labeledSet_key = labeledSet_key,
                        outputType=outputType, ignoreCase=ignoreCase,
                        stripTags=stripTags, stem=stem, removePunctuation=removePunctuation,
                        stopWords=stopWords, removeNumbers=removeNumbers, minFreq=minFreq, maxFreq=maxFreq, language=language, verbose=T) ) 
  }
  
  if(undergradVersion == "2"){ 
    if(!is.null(wordVecs_corpusPointer)){ 
      wordVecs_corpus <- fread(wordVecs_corpusPointer)
    } 
    key_list <- wordVecs_corpus[[1]]
    documentText <- strsplit(documentText, split = " ")
    documentText <- lapply(documentText, function(x) return(  x[x!=""]) )  
    documentText_unique <- unique(  unlist(documentText) )  
    
    pointer_vec <- 1:length(key_list)
    names(pointer_vec) <- key_list
    wordsUsed_unique_pointers <- pointer_vec[names(pointer_vec) %in% documentText_unique]
    wordsUsed_unique <- names(wordsUsed_unique_pointers)
    percent_dropped <-  round(100*mean( !documentText_unique %in% key_list ),2)
    if(percent_dropped > 0){ 
      print(sprintf("Warning: %s percent of unique words have no vector analogue", percent_dropped   )  )
    } 
    rm(key_list);
  
    temp <- lapply(documentText,function(x){ return( unname(wordsUsed_unique_pointers[ x] ) )  } )
    
    vecs_full_list <- lapply(temp, function(qwer) { 
      vecs_list <- wordVecs_corpus[qwer,-1]#first column is word keys. 
    } )
    rm(temp); rm(wordVecs_corpus)
    
    DocSummaries <- lapply(vecs_full_list, function(x){
      DocVecs_sorted <- apply(x, 2, sort)
      if(class(DocVecs_sorted)!="matrix"){DocVecs_sorted <- rbind(t(DocVecs_sorted),t(DocVecs_sorted)) }
      DocMedian <- DocVecs_sorted[round(nrow(DocVecs_sorted)/2),] 
      DocMax <- DocVecs_sorted[nrow(DocVecs_sorted),]
      DocMin <- DocVecs_sorted[1,]
      DocSummary <- c(DocMin, DocMedian, DocMax) 
      if(length(DocSummary) == 0){DocSummary <- rep(NA, times = ncol(wordVecs_corpus)-1)}
      return(  DocSummary  )
    } )
    rm(vecs_full_list)
    
    DocSummaries <- do.call(rbind, DocSummaries); DocSummaries[is.na(DocSummaries)] <- NA
    colnames(DocSummaries) <- paste("V", 1:ncol(DocSummaries), sep = "") 
    DocSummaries <- apply(DocSummaries, 2, function(x){ x[is.na(x)] <- mean(x, na.rm = T); return(x) })
    n_trim <- max(1,round(nrow(DocSummaries) * 0.015))
    if(n_trim /nrow(DocSummaries) < 0.10){ 
      DocSummaries <- DocSummaries[,apply(DocSummaries, 2, sd)>0]
      DocSummaries <- apply(DocSummaries, 2, function(x){
        x <- Winsorize(x, prob = c(n_trim/nrow(DocSummaries), (nrow(DocSummaries) - n_trim)/ nrow(DocSummaries) )) })
    } 
    DocSummaries <- FastScale(DocSummaries); 
    DocSummaries <- DocSummaries[,!is.na(colSums(DocSummaries))]
    return( DocSummaries )
  } 
}
